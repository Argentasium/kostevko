export default function Footer() {
    const currentYear = new Date().getFullYear();
    return <footer className="footer-block">ТРВП-018. РК6-73Б Костевко Дарья. ©{currentYear} Все парава защищены.</footer>;
}
